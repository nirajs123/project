

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class A
 */
@WebServlet("*.do")
public class A extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private Client c;
    
 	public void init(ServletConfig config) throws ServletException {
 		c=new Client();
	}

	
	public void destroy() {
		c=null;
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcessRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcessRequest(request, response);
	}

	protected void doProcessRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException
	{
		String path = request.getServletPath();
		System.out.println(path);
		if(path.equals("/check.do"))
		{
		String job1=request.getParameter("job1");
		String job2=request.getParameter("job2");
		String job3=request.getParameter("job3");
		String job4=request.getParameter("job4");
		String job5=request.getParameter("job5");
		
	List<BusBean> b =c.checkDataForSearch(job1,job2,job3,job4,job5);
		//List<BusBean> b =c.checkDataForSearch(job1);
		for (BusBean busBean : b) {
			System.out.println(busBean);
		}
	/*for (String string : a) {
		System.out.println(string);
		//List<BusBean> b =c.checkDataForSearch(string);
		for (BusBean busBean : b) {
			System.out.println(busBean);
		}*/
	}
	
	//System.out.println(a.toString());
	
	
	
	}
	
	}

