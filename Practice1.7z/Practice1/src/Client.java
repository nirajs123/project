import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class Client {
	
	public List<BusBean> checkDataForSearch(String a, String job2, String job3, String job4, String job5)
	{
		//Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		List<BusBean> elist=new ArrayList<BusBean>();
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 Connection con = DriverManager.
			            getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g"
			                ,"labg104trg18","labg104oracle");
			 System.out.println("Connected");
			
			
				 	
					String query="select * from emp where job IN (?,?,?,?,?)";
					 pstmt=con.prepareStatement(query);
					 pstmt.setString(1, a);
					 pstmt.setString(2, job2);
					 pstmt.setString(3, job3);
					 pstmt.setString(4, job4);
					 pstmt.setString(5, job5);
					 rs=pstmt.executeQuery();
					 while (rs.next())
						{
						 System.out.println("hiiiii");
							BusBean e = new BusBean(); 
							int empId=rs.getInt("EMPNO");
							String ename=rs.getString("ENAME");
							String j=rs.getString("job");
							//String as=j.toString();
							e.setBusId(empId);
							e.setFromStop(ename);
							e.setToStop(j);
							elist.add(e);
							
						}
				
					
				
			 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
return elist;
		
	}
	
	
/*	public static void main(String[] args) {
		Client c=new Client();
		List<BusBean> b=c.checkDataForSearch("MANAGER","CLERK", null, "SALESMAN", null);
		for (BusBean busBean : b) {
			
			System.out.println(busBean);
			
		}*/
	}


